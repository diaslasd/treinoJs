const ex = require('./exportar')

console.log(ex, ex.a, ex.b, ex.c)

console.log(global.ola)