this.ola = 'Fala Pessoal'
exports.bemVindo = 'Bem vindo ao node!'
module.exports.atelogo = 'Até próximo exemplo'

const soma = 5 + 6
this.total = soma
