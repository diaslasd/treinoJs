$A = 10
$B = 100
$TOTAL = $A * $B
echo "Ola mundo!. PowerShell eh $TOTAL"