const sequencia = {
    _valor: 1, // convenção
    
}